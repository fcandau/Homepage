

library(tidyverse)
library(data.table)
library(dplyr)
library(sf)

library(tidyverse)
library(here)
library(fixest)
library(kfbmisc)
library(patchwork)
library(lpridge)
library(KernSmooth)
library(data.table)

setwd("C:/eco spat/BASE YOUNOUSSA")

df<-fread('BASE_TELETRAVAIL.csv', header=T, sep=';',dec='.', encoding = "Latin-1")

df$insee <- ifelse(nchar(df$insee) == 4, paste0("0", df$insee), df$insee)


#df$datefibre<-ifelse(df$datefibre>=2021, 0,df$datefibre)
#df<-subset(df, df$annee<=2021)

df$treat = ifelse((df$datefibre <= df$annee) & (df$datefibre != 0), 1,0)

df2 <- df %>%
  group_by(insee) %>%
  summarise(somme_treat = max(treat))

df <- df  |>
  left_join(df2, by = "insee")

df$somme_treat<-ifelse(df$datefibre==0 , 0,1)


#df$somme_treat<-ifelse(df$datefibre==0 | df$datefibre>=2021, 0,1)



########joindre le centroide des communes 

##ctr_pop<-st_read(dsn="D:/eco spat/data fibres estimations/communes-20220101.shp", stringsAsFactors=F)
ctr_pop<-st_read(dsn="C:/eco spat/BASE YOUNOUSSA/centroid_communes.shp", stringsAsFactors=F)
##ctr_pop<-st_centroid(ctr_pop)


df <- df  |>
  left_join(ctr_pop, by = "insee") |>
  st_as_sf()

df<-dplyr::filter(df, !sf::st_is_empty(geometry))##


df_treat<-subset(df, df$somme_treat==1)

df_treat <- df_treat[!duplicated(df_treat$geometry), ]




##df_treat<-subset(df_treat, df_treat$insee==10081)


d<-st_distance(df, df_treat)


##min_distances <- apply(d, 1, min)

#min_distances <- apply(d, 1, function(x) min(x[x != 0], na.rm = TRUE))



###que datefibre<datefibre2 tout en 1 Bon

result <- t(sapply(seq_len(nrow(d)), function(i) {
  distances <- as.numeric(d[i, ])
  valid_indices <- which((df_treat$datefibre < df$datefibre[i]) | (df$datefibre[i]==0))
  
  if (length(valid_indices) == 0) return(c(NA, NA))
  
  row_filtered <- distances[valid_indices]
  if (all(is.na(row_filtered))) return(c(NA, NA))
  
  min_index <- valid_indices[which.min(row_filtered)]
  min_distance <- min(row_filtered, na.rm = TRUE)
  
  return(c(min_distance, min_index))
}))

min_distances <- result[, 1]  # Distances minimales
closest_index <- result[, 2]   # Indices correspondants


#######



# Ajouter les distances minimales au jeu de données base_cine
df$min_distance <- min_distances




df$insee2 <- df_treat$insee[closest_index]

df$datefibre2 <- df_treat$datefibre[closest_index]


df$tele2 <- df_treat$tele[closest_index]


#df<-as.data.frame(df)
#df<-subset(df, select=-c(geometry))

df$i<-df$insee

df3<-df


#df<-subset(df, (df$treat==0))


#df<-subset(df, (df$treat==0) | (df$datefibre>df$datefibre2))

#si je voulais garder les 0 distance il faut ajouter les  min_distance==0 et faire en 2 fois 1 fois faire calcul distances sans les 0 puis ne garder que les treat ==0 puis faire calculs avec les 0 et ne gardr que les min_distances==0 puis on rbind les 2 bases
#df<-subset(df,  (df$min_distance==0))


#df<-subset(df, (df$treat==0))

#df<-subset(df,  (df$datefibre>df$datefibre2))

df$t<-df$treat
df$dd<-df$datefibre
df$aa<-df$annee


######"microdata bonne

df2<-df

df<-df%>%rename(distance=min_distance)


#base_ips$close_offender<-ifelse(base_cine$distance<=10000, 1,0)

df$close_offender<-ifelse(df$distance<=1000, 1,0)

##base_ips$ann_scl<-as.numeric(base_ips$ann_scl)
##base_ips$annee_crea<-as.numeric(base_ips$annee_crea)


#df$offdays<-df$datefibre2 - df$datefibre


df$offdays<-df$annee - df$datefibre2

##df$offdays<-ifelse(df$offdays>=2000,0,df$offdays)

#df$post_move<-ifelse(df$datefibre2>df$datefibre, 1,0)


df$post_move<-ifelse(df$annee>df$datefibre2, 1,0)

df$close_post_move<-df$close_offender*df$post_move


df <- df %>%
  mutate(
    distance = distance ,
    dist_post = distance * 10 * close_post_move,
    post = ifelse(post_move, "Post", "Pre"),
    offdays = annee - datefibre2
  )

##df<-subset(df, )

df2<-df
###

df<-df2

df$distance<-df$distance/1000



df<-subset(df, df$distance<=50)


df22<-df

df22<-subset(df22, (df22$treat==0))

df22$anbrecreaentr<-asinh(df22$nbrecreaentr)
df22$anbentrtot<-asinh(df22$nbentrtot)
df22$atele<-asinh(df22$tele)
df22$ateletravail<-asinh(df22$teletravail)

nonparametric_ring_cs <- function(y, dist, post) {
  est <- binsreg::binsreg(
    y = y, x = dist,w=cbind(factor(df22$insee), factor(df22$annee) , df22$partcadre, df22$partinfocom), by = as.logical(post),
    samebinsby = T, randcut = 1,
    line = c(0, 0), ci = c(0, 0), vce = "HC3", # Use a valid option like "HC3"
    cluster = df22$insee
  )
  
  post_line <- data.table::as.data.table(est$data.plot$`Group TRUE`$data.line)
  post_line <- post_line[, .(x, bin, post_fit = fit)]
  pre_line <- data.table::as.data.table(est$data.plot$`Group FALSE`$data.line)
  pre_line <- pre_line[, .(x, bin, pre_fit = fit)]
  
  post_se <- data.table::as.data.table(est$data.plot$`Group TRUE`$data.ci)
  post_se <- post_se[
    , post_se := (ci.r - ci.l) / 2 / 1.96
  ][
    , .(bin, post_se)
  ]
  
  
  pre_se <- data.table::as.data.table(est$data.plot$`Group FALSE`$data.ci)
  pre_se <- pre_se[
    , pre_se := (ci.r - ci.l) / 2 / 1.96
  ][
    , .(bin, pre_se)
  ]
  
  post_line <- merge(post_line, post_se, by = "bin")
  pre_line <- merge(pre_line, pre_se, by = "bin")
  
  line <- merge(pre_line, post_line, by = c("x", "bin"))
  
  line[, let(
    tau = post_fit - pre_fit,
    se = sqrt(pre_se^2 + post_se^2)
  )][, let(
    ci_lower = tau - 1.96 * se,
    ci_upper = tau + 1.96 * se
  )]
  
  # Counterfactual Trend
  count_trend <- line[bin == max(bin) & !is.na(tau)][1, ]$tau
  
  line[, let(
    tau = tau - count_trend,
    ci_lower = ci_lower - count_trend,
    ci_upper = ci_upper - count_trend
  )]
  
  line[line$bin == max(line$bin), let(se = 0, ci_lower = 0, ci_upper = 0)]
  
  # Right-most endpoint needs NA column
  line <- rbind(line[, .(bin, x, tau, se, ci_lower, ci_upper)], data.table(
    bin = max(line$bin), x = max(line$x), tau = NA, se = 0, ci_lower = NA, ci_upper = NA
  ))
  
  # Subset to left and right endpoints
  line <- line[, .SD[c(1, .N-1, .N), ], by=bin]
  
  return(line)
}

############################## Firm creation 

line <- nonparametric_ring_cs(df22$nbrecreaentr, df22$distance, df22$post == "Post")







(p <- ggplot() +
    # 0
    geom_hline(yintercept = 0, linetype = "dashed") +
    # Line
    geom_line(
      data = line, mapping = aes(x = x, y = tau),
      color = "#3e3788", size = 1.2
    ) +
    # CI
    geom_ribbon(
      data = line, mapping = aes(x = x, ymin = ci_lower, ymax = ci_upper),
      color = "#3e3788", fill = "#3e3788", alpha = 0.2
    ) +
    theme_kyle(base_size = 10)) +
  theme_kyle(base_size = 14) +
  labs(x = "Distance to treated municipality", y = "Firm creations")





################################# Effect on teleworkers 


nonparametric_ring_cs <- function(y, dist, post) {
  est <- binsreg::binsreg(
    y = y, x = dist,w=cbind(factor(df22$insee), factor(df22$annee) , df22$partcadre, df22$partinfocom,df22$nbentrtot), by = as.logical(post),
    samebinsby = T, randcut = 1,
    line = c(0, 0), ci = c(0, 0), vce = "HC3", # Use a valid option like "HC3"
    cluster = df22$insee
  )
  
  post_line <- data.table::as.data.table(est$data.plot$`Group TRUE`$data.line)
  post_line <- post_line[, .(x, bin, post_fit = fit)]
  pre_line <- data.table::as.data.table(est$data.plot$`Group FALSE`$data.line)
  pre_line <- pre_line[, .(x, bin, pre_fit = fit)]
  
  post_se <- data.table::as.data.table(est$data.plot$`Group TRUE`$data.ci)
  post_se <- post_se[
    , post_se := (ci.r - ci.l) / 2 / 1.96
  ][
    , .(bin, post_se)
  ]
  
  
  pre_se <- data.table::as.data.table(est$data.plot$`Group FALSE`$data.ci)
  pre_se <- pre_se[
    , pre_se := (ci.r - ci.l) / 2 / 1.96
  ][
    , .(bin, pre_se)
  ]
  
  post_line <- merge(post_line, post_se, by = "bin")
  pre_line <- merge(pre_line, pre_se, by = "bin")
  
  line <- merge(pre_line, post_line, by = c("x", "bin"))
  
  line[, let(
    tau = post_fit - pre_fit,
    se = sqrt(pre_se^2 + post_se^2)
  )][, let(
    ci_lower = tau - 1.96 * se,
    ci_upper = tau + 1.96 * se
  )]
  
  # Counterfactual Trend
  count_trend <- line[bin == max(bin) & !is.na(tau)][1, ]$tau
  
  line[, let(
    tau = tau - count_trend,
    ci_lower = ci_lower - count_trend,
    ci_upper = ci_upper - count_trend
  )]
  
  line[line$bin == max(line$bin), let(se = 0, ci_lower = 0, ci_upper = 0)]
  
  # Right-most endpoint needs NA column
  line <- rbind(line[, .(bin, x, tau, se, ci_lower, ci_upper)], data.table(
    bin = max(line$bin), x = max(line$x), tau = NA, se = 0, ci_lower = NA, ci_upper = NA
  ))
  
  # Subset to left and right endpoints
  line <- line[, .SD[c(1, .N-1, .N), ], by=bin]
  
  return(line)
}

############################## Firm creation 

line <- nonparametric_ring_cs(df22$tele, df22$distance, df22$post == "Post")







(p <- ggplot() +
    # 0
    geom_hline(yintercept = 0, linetype = "dashed") +
    # Line
    geom_line(
      data = line, mapping = aes(x = x, y = tau),
      color = "#3e3788", size = 1.2
    ) +
    # CI
    geom_ribbon(
      data = line, mapping = aes(x = x, ymin = ci_lower, ymax = ci_upper),
      color = "#3e3788", fill = "#3e3788", alpha = 0.2
    ) +
    theme_kyle(base_size = 10)) +
  theme_kyle(base_size = 14) +
  labs(x = "Distance to treated municipality", y = "Share of teleworkers ")




