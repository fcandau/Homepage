library(tidyverse, warn.conflicts = FALSE)
library(sf)
library(kfbmisc)
library(fixest)
library(did2s, quietly = TRUE)
library(data.table)
library(MatchIt)
library(PSweight)



setwd("C:/Users/Yaoumarou/Desktop/Thèse/Teletravail/BASE YOUNOUSSA")

df<-fread('BASE_TELETRAVAIL.csv', header=T, sep=';',dec='.', encoding = "Latin-1")

df$insee <- ifelse(nchar(df$insee) == 4, paste0("0", df$insee), df$insee)
########joindre le centroide des communes 

##ctr_pop<-st_read(dsn="D:/eco spat/data fibres estimations/communes-20220101.shp", stringsAsFactors=F)
ctr_pop<-st_read(dsn="C:/Users/Yaoumarou/Desktop/Thèse/Teletravail/BASE YOUNOUSSA/centroid_communes.shp", stringsAsFactors=F)
##ctr_pop<-st_centroid(ctr_pop)


df <- df  |>
  left_join(ctr_pop, by = "insee") |>
  st_as_sf()

df<-dplyr::filter(df, !sf::st_is_empty(geometry))##

##########




####voici les fonctions qui servent à calculer les spillovers

## helper function: for each year, calculate within


within_x_treat <- function(dist, annee, datefibre, geometry) {
  y <- min(annee)
  
  # Last term is because Bailey and Goodman-Bacon define it for chc's before 1974
  treated <- (datefibre <= y) & (datefibre > 0) 
  
  
  dist_mat <- st_distance(geometry, geometry) |>
    units::set_units("km") |>
    units::drop_units()
  
  within <- (dist_mat > 0) & (dist_mat < dist) 
  
  return(as.numeric((within %*% treated) > 0))
}


################################

## helper function: find minimum year that within == 1, requires sorted!
min_year <- function(annee, within) {
  if (any(within == 1)) {
    idx <- which(within == 1)[1]
    y <- annee[idx]
  } else {
    y <- 0
  }
  
  return(y)
}


##bon
df_spill <- df  |> group_by(annee) |>
  filter(annee <= 2022) |>
  # Create within indicator
  mutate(
    # Create D_it
    treat = as.numeric((datefibre <= annee) & (datefibre != 0)),
    # Create S_it
    within_25 = within_x_treat(15, annee, datefibre, geometry), ###ici ce sont les spillovers à 15km de la commune traitée tu peux le changer
    # S_it (1 - D_it)
    within_25 = within_25 * (1 - treat)
  ) |>
  ungroup() |>
  # Arrange panel by fips year
  arrange(insee, annee) |>
  group_by(insee) |>
  mutate(
    # Create D_it^k's
    rel_year = case_when(
      datefibre == 0 ~ -1,
      TRUE ~ annee - datefibre
    ),
    # Minimum year where S_it = 1
    year_within_25 = min_year(annee, within_25),
    # Create S_it^k
    spill_rel_year = case_when(
      year_within_25 == 0 ~ -Inf,
      treat == 1 ~ -Inf,
      TRUE ~ annee - year_within_25
    ),
    # max(D_it, S_it)
    treat_or_spill = treat + within_25,
    # Create trend variables for controls
    stfips_trend = as.factor(paste(annee, insee, sep = "_")),
    stfips_trend = as.factor(as.numeric(stfips_trend)),
  ) |>
  ungroup()



df_spill$tele<-df_spill$teletravail/df_spill$actifoccupe
df_spill$partcadre<-df_spill$cadre/df_spill$actifoccupe
df_spill$partinfocom<-df_spill$infocom_naf/df_spill$actifoccupe
df_spill$lteletravail<-log(df_spill$teletravail)
df_spill$lcadre<-log(df_spill$cadre)
df_spill$linfocom<-log(df_spill$infocom_naf)

df_spill$partnombreinfocom06<-df_spill$`Nombre.d.Ã©tablissements.2006.infocom`/df_spill$`Nombre.d.Ã©tablissements.2006`
df_spill$partnombreinfocom06<-ifelse(is.na(df_spill$partnombreinfocom06), 0, df_spill$partnombreinfocom06)


df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe

### main results 

################ results without spillovers 

#################################################
########################code pour event study



event_study = function(data, yname, idname, gname, tname,
                       xformla = NULL, weights = NULL,
                       estimator = c("all", "TWFE", "did2s", "did", "impute", "sunab",
                                     "staggered")
){
  
  # Check Parameters -------------------------------------------------------------
  
  # Select estimator
  estimator <- match.arg(estimator)
  
  # Display message about estimator's different assumptions
  if(estimator == "all") {
    message("Note these estimators rely on different underlying assumptions. See Table 2 of `https://arxiv.org/abs/2109.05913` for an overview.")
  }
  
  
  # Test that there exists never-treated units
  if(!any(
    unique(data[[gname]]) %in% c(0, NA)
  )) {
    stop(
      "event_study only works when there is a never-treated groups. This will be updated in the future, though with fewer estimators."
    )
  }
  
  # If `xformla` is included, note
  if(!is.null(xformla)) {
    if(estimator %in% c("all", "staggered")) {
      message(paste0("Warning: `", xformla, "` is ignored for the `staggered` estimator"))
    }
  }
  
  # Setup ------------------------------------------------------------------------
  
  # Treat
  data$zz000treat = 1 * (data[[tname]] >= data[[gname]]) * (data[[gname]] > 0)
  data[is.na(data$zz000treat), "zz000treat"] = 0
  
  # Set g to zero if NA
  data[is.na(data[[gname]]), gname] = 0
  
  # Create event time
  data$zz000event_time = ifelse(
    is.na(data[[gname]]) | data[[gname]] == 0 | data[[gname]] == Inf,
    -Inf,
    as.numeric(data[[tname]] - data[[gname]])
  )
  
  event_time = unique(data$zz000event_time)
  event_time = event_time[!is.na(event_time) & is.finite(event_time)]
  
  # Format xformla for inclusion
  if(!is.null(xformla)) {
    xformla_null = paste0("0 + ", as.character(xformla)[[2]])
  } else {
    xformla_null = "0"
  }
  
  
  
  # initialize empty arguments
  tidy_twfe = NULL
  tidy_did2s = NULL
  tidy_did = NULL
  tidy_sunab = NULL
  tidy_impute = NULL
  tidy_staggered = NULL
  
  # TWFE -------------------------------------------------------------------------
  if(estimator %in% c("TWFE", "all")) {
    message("Estimating TWFE Model")
    
    try({
      twfe_formula = stats::as.formula(
        paste0(
          yname, " ~ 1 + ", xformla_null, " + i(zz000event_time, ref = c(-1, -Inf)) | ", idname, " + ", tname
        )
      )
      est_twfe = fixest::feols(twfe_formula, data = data, warn = F, notes = F)
      
      # Extract coefficients and standard errors
      tidy_twfe = broom::tidy(est_twfe)
      
      # Extract zz000event_time
      tidy_twfe = tidy_twfe[grep("zz000event_time::", tidy_twfe$term), ]
      
      # Make event time into a numeric
      tidy_twfe$term = as.numeric(gsub("zz000event_time::", "", tidy_twfe$term))
      
      # Subset column
      tidy_twfe = tidy_twfe[, c("term", "estimate", "std.error")]
    })
    
    if(is.null(tidy_twfe)) warning("TWFE Failed")
  }
  
  # did2s ------------------------------------------------------------------------
  if(estimator %in% c("did2s", "all")) {
    message("Estimating using Gardner (2021)")
    
    try({
      did2s_first_stage = stats::as.formula(
        paste0(
          "~ 0 + ", xformla_null, " | ", idname, " + ", tname
        )
      )
      
      est_did2s = did2s::did2s(data, yname = yname, first_stage = did2s_first_stage, second_stage = ~i(zz000event_time, ref=-Inf), treatment = "zz000treat", cluster_var = idname, verbose = FALSE)
      
      # Extract coefficients and standard errors
      tidy_did2s = broom::tidy(est_did2s)
      
      # Extract zz000event_time
      tidy_did2s = tidy_did2s[grep("zz000event_time::", tidy_did2s$term), ]
      
      # Make event time into a numeric
      tidy_did2s$term = as.numeric(gsub("zz000event_time::", "", tidy_did2s$term))
      
      # Subset columns
      tidy_did2s = tidy_did2s[, c("term", "estimate", "std.error")]
    })
    
    if(is.null(tidy_did2s)) warning("Gardner (2021) Failed")
  }
  
  # did --------------------------------------------------------------------------
  if(estimator %in% c("did", "all")) {
    message("Estimating using Callaway and Sant'Anna (2020)")
    
    try({
      est_did = did::att_gt(yname = yname, tname = tname, idname = idname, gname = gname, xformla = xformla, data = data, panel=F, control_group = c("notyettreated"), est_method="ipw")
      
      est_did = did::aggte(est_did, type = "dynamic", na.rm = TRUE)
      
      # Extract es coefficients
      tidy_did = broom::tidy(est_did)
      
      # Subset columns
      tidy_did$term = tidy_did$event.time
      tidy_did = tidy_did[, c("term", "estimate", "std.error")]
    })
    
    if(is.null(tidy_did)) warning("Callaway and Sant'Anna (2020) Failed")
  }
  
  # sunab ------------------------------------------------------------------------
  if(estimator %in% c("sunab", "all")) {
    message("Estimating using Sun and Abraham (2020)")
    
    try({
      # Format xformla for inclusion
      if(is.null(xformla)) {
        sunab_xformla = "1"
      } else {
        sunab_xformla = paste0("1 + ", as.character(xformla)[[2]])
      }
      
      sunab_formla = stats::as.formula(
        paste0(
          yname, " ~ ", sunab_xformla, " + sunab(", gname, ", zz000event_time, ref.c =0, ref.p = -1) | ", idname, " + ", tname
        )
      )
      
      est_sunab = fixest::feols(sunab_formla, data = data)
      
      tidy_sunab = broom::tidy(est_sunab)
      
      # Extract zz000event_time
      tidy_sunab = tidy_sunab[grep("zz000event_time::", tidy_sunab$term), ]
      
      # Make event time into a numeric
      tidy_sunab$term = as.numeric(gsub("zz000event_time::", "", tidy_sunab$term))
      
      # Subset columns
      tidy_sunab = tidy_sunab[, c("term", "estimate", "std.error")]
    })
    
    if(is.null(tidy_sunab)) warning("Sun and Abraham (2020) Failed")
  }
  
  # did_imputation ---------------------------------------------------------------
  if(estimator %in% c("impute", "all")) {
    message("Estimating using Borusyak, Jaravel, Spiess (2021)")
    
    try({
      impute_first_stage = stats::as.formula(
        paste0(
          "~ 1 + ", xformla_null, "+ i(", tname, ") | ", idname
        )
      )
      
      tidy_impute = didimputation::did_imputation(data,
                                                  yname = yname, gname = gname, tname = tname, idname = idname,
                                                  first_stage = impute_first_stage, horizon = TRUE, pretrends = TRUE)
      
      # Subset columns
      tidy_impute = tidy_impute[, c("term", "estimate", "std.error")]
      
      tidy_impute = tidy_impute[grep("^(-)?[0-9]+$", tidy_impute$term), ]
      
      # Make event time into a numeric
      tidy_impute$term = as.numeric(tidy_impute$term)
    })
    
    if(is.null(tidy_impute)) warning("Borusyak, Jaravel, Spiess (2021) Failed")
  }
  
  # staggered --------------------------------------------------------------------
  if(estimator %in% c("staggered", "all")) {
    # Waiting for staggered on CRAN
    message("Estimating using Roth and Sant'Anna (2021)")
    
    try({
      # Make untreated g = Inf
      data_staggered = data
      
      data_staggered[,gname] = ifelse(
        data_staggered[[gname]] == 0,
        Inf,
        data_staggered[[gname]]
      )
      
      event_time_staggered = event_time[is.finite(event_time) & event_time != -1]
      event_time_staggered = event_time_staggered[event_time_staggered != min(event_time_staggered) ]
      
      tidy_staggered = staggered::staggered(
        data_staggered,
        i = idname, t = tname, g = gname, y = yname, estimand = "eventstudy",
        eventTime = event_time_staggered
      )
      
      # Subset columns
      tidy_staggered$term = tidy_staggered$eventTime
      tidy_staggered$std.error = tidy_staggered$se
      
      tidy_staggered = tidy_staggered[, c("term", "estimate", "std.error")]
    })
    
    if(is.null(tidy_staggered)) warning("Roth and Sant'Anna (2021) Failed")
  }
  
  # Bind results together --------------------------------------------------------
  
  out = data.table::rbindlist(list(
    "TWFE" = tidy_twfe,
    "Gardner (2021)" = tidy_did2s,
    "Callaway and Sant'Anna (2020)" = tidy_did,
    "Sun and Abraham (2020)" = tidy_sunab,
    "Roth and Sant'Anna (2021)" = tidy_staggered,
    "Borusyak, Jaravel, Spiess (2021)" = tidy_impute
  ), idcol = "estimator")
  
  return(out)
  
}


#' Plot results of [event_study()]
#' @param out Output from [event_study()]
#' @param separate Logical. Should the estimators be on separate plots? Default is TRUE.
#' @param horizon Numeric. Vector of length 2. First element is min and
#'   second element is max of event_time to plot
#'
#' @return `plot_event_study` returns a ggplot object that can be fully customized
#'
#' @rdname event_study
#'
#' @importFrom rlang .data
#' @export
plot_event_study = function(out, separate = TRUE, horizon = NULL) {
  
  # Get list of estimators
  estimators = unique(out$estimator)
  
  # Subset factor levels
  levels = c("TWFE", "Borusyak, Jaravel, Spiess (2021)", "Callaway and Sant'Anna (2020)", "Gardner (2021)", "Roth and Sant'Anna (2021)",  "Sun and Abraham (2020)")
  levels = levels[levels %in% estimators]
  
  # Make estimator into factor
  out$estimator = factor(out$estimator, levels = levels)
  
  
  # Subset color scales
  color_scale = c("TWFE" = "#374E55", "Gardner (2021)" = "#DF8F44", "Callaway and Sant'Anna (2020)" = "#00A1D5", "Sun and Abraham (2020)" = "#B24745", "Roth and Sant'Anna (2021)" = "#79AF97", "Borusyak, Jaravel, Spiess (2021)" = "#6A6599")
  color_scale = color_scale[names(color_scale) %in% estimators]
  
  
  # create confidence intervals
  out$ci_lower = out$estimate - 1.96 * out$std.error
  out$ci_upper = out$estimate + 1.96 * out$std.error
  
  
  # position depending on separate
  if(separate) position = "identity" else position = ggplot2::position_dodge(width = 0.5)
  
  # Subset plot if horizon is specified
  if(!is.null(horizon)) {
    out = out[out$term >= horizon[1] & out$term <= horizon[2], ]
  }
  
  # max and min of limits
  y_lims = c(min(out$ci_lower), max(out$ci_upper)) * 1.05
  x_lims = c(min(out$term) - 1, max(out$term) + 1)
  
  ggplot2::ggplot(
    data = out,
    mapping = ggplot2::aes(
      x = .data$term, y = .data$estimate,
      color = .data$estimator,
      ymin = .data$ci_lower, ymax = .data$ci_upper
    )
  ) +
    { if(separate) ggplot2::facet_wrap(~ estimator, scales="free") } +
    ggplot2::geom_point(position = position) +
    ggplot2::geom_errorbar(position = position) +
    ggplot2::geom_vline(xintercept = -0.5, linetype = "dashed") +
    ggplot2::geom_hline(yintercept = 0, linetype = "dashed") +
    ggplot2::labs(y = "Share of telewokers ", x = "Event Time", color = "Estimator") +
    { if(separate) ggplot2::scale_y_continuous(limits = y_lims) } +
    { if(separate) ggplot2::scale_x_continuous(limits = x_lims) } +
    ggplot2::theme_minimal(base_size = 11) +
    ggplot2::scale_color_manual(values = color_scale) +
    ggplot2::guides(
      color = ggplot2::guide_legend(title.position = "top", nrow = 2)
    ) +
    ggplot2::theme(legend.position = "bottom")
  
}





##df2$datefibre<-ifelse(df2$datefibre>=2020, 0, df2$datefibre)

out = event_study(
  data = df_spill2, yname = "parttele", idname = "insee",
  tname = "annee", gname = "datefibre", estimator = "impute", xformla = ~ 0  )


plot_event_study(out, horizon = c(-10, 9))



######################## Resuluts with spillovers 



es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers ", x = "Event Time", color = NULL)





################## impact in IC sector



############### Sorting to keep IC sector 

df_spill2$spill_rel_year = case_when(
  df_spill2$partnombreinfocom06 <= 0.05        |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$spill_rel_year
)

df_spill2$year_within_25 = case_when(
  df_spill2$partnombreinfocom06 <= 0.05      |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$year_within_25
)



df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)



################### results 

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of teleworkers ", x = "Event Time", color = NULL)







#################################### extentions 


##########   result according to the type of cities 


################################## Telecommuters 

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



########## densite =1


df_spill2$rel_year = case_when(
   df_spill2$densite == 4 | df_spill2$densite == 3  | df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
 df_spill2$densite == 4  | df_spill2$densite ==3  | df_spill2$densite == 2 ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~ i(treat, 0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)


##### spillovers


es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~ i(spill, 0),
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)

######### densite = 2


df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 3| df_spill2$densite == 4   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  1| df_spill2$densite == 3 | df_spill2$densite == 4  ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000


es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~  i(treat, 0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)

############### Spillovers 

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~ i(spill, 0),
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)

################ densite = 3| densite = 4




df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 2     ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  1| df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)

df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000



es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~  i(treat, 0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)

##############

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~  partcadre+  partinfocom +nbentrtot1000 | insee+annee ,
    second_stage = ~ i(spill, 0),
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)



########### Mechanism (firm creation)

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "nbrecreaentr",
  first_stage = ~ partcadre + partinfocom   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of firm creations ", x = "Event Time", color = NULL)



############ IC sector 




df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000




df_spill$partnombreinfocom06<-df_spill$`Nombre.d.Ã©tablissements.2006.infocom`/df_spill$`Nombre.d.Ã©tablissements.2006`
df_spill$partnombreinfocom06<-ifelse(is.na(df_spill$partnombreinfocom06), 0, df_spill$partnombreinfocom06)



############### Sorting to keep IC sector 



df_spill2$spill_rel_year = case_when(
  df_spill2$partnombreinfocom06 <= 0.05        |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$spill_rel_year
)

df_spill2$year_within_25 = case_when(
  df_spill2$partnombreinfocom06 <= 0.05      |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$year_within_25
)





df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "ninfocom",
  first_stage = ~ partcadre + partinfocom  | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of firm creations in information 
         \n and communication sector", x = "Event Time", color = NULL)




################################## Type of cities :  Firm creation  

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe




########## densite =1


df_spill2$rel_year = case_when(
  df_spill2$densite == 4 | df_spill2$densite == 3  | df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite == 4  | df_spill2$densite ==3  | df_spill2$densite == 2 ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom +pop | insee+annee ,
    second_stage = ~  i(treat, 0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)



############# spillovers

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom +pop| insee+annee ,
    second_stage = ~  i(spill, 0),
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)




######### densite = 2


df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 3| df_spill2$densite == 4   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  3| df_spill2$densite == 1 | df_spill2$densite == 4  ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000


es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom +pop| insee+annee ,
    second_stage = ~  i(treat, 0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)


################### spillovers

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom +pop | insee+annee ,
    second_stage = ~  i(spill, 0) ,
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)


################ densite = 3| densite = 4




df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 2     ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  1| df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)

df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000



es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom  +pop| insee+annee ,
    second_stage = ~  i(treat, 0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1)

################## spillovers

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~  partcadre+  partinfocom +pop| insee+annee ,
    second_stage = ~  i(spill, 0),
    treatment = "treat",
    cluster_var = "insee"
  )


summary(es_1)


################# All estimators (Appendix A)

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


######################### teleworkers 



out = event_study(
  data = df_spill2, yname = "parttele", idname = "insee",
  tname = "annee", gname = "datefibre", estimator = "all", xformla = ~ 0  )


plot_event_study(out, horizon = c(-10, 9))

######################### firm creations 


out = event_study(
  data = df_spill2, yname = "nbrecreaentr", idname = "insee",
  tname = "annee", gname = "datefibre", estimator = "all", xformla = ~ 0  )


plot_event_study(out, horizon = c(-10, 9))




############################## No Spillovers at 25 km (Appendix B)

df_spill <- df  |> group_by(annee) |>
  filter(annee <= 2022) |>
  # Create within indicator
  mutate(
    # Create D_it
    treat = as.numeric((datefibre <= annee) & (datefibre != 0)),
    # Create S_it
    within_25 = within_x_treat(25, annee, datefibre, geometry), ###ici ce sont les spillovers à 15km de la commune traitée tu peux le changer
    # S_it (1 - D_it)
    within_25 = within_25 * (1 - treat)
  ) |>
  ungroup() |>
  # Arrange panel by fips year
  arrange(insee, annee) |>
  group_by(insee) |>
  mutate(
    # Create D_it^k's
    rel_year = case_when(
      datefibre == 0 ~ -1,
      TRUE ~ annee - datefibre
    ),
    # Minimum year where S_it = 1
    year_within_25 = min_year(annee, within_25),
    # Create S_it^k
    spill_rel_year = case_when(
      year_within_25 == 0 ~ -Inf,
      treat == 1 ~ -Inf,
      TRUE ~ annee - year_within_25
    ),
    # max(D_it, S_it)
    treat_or_spill = treat + within_25,
    # Create trend variables for controls
    stfips_trend = as.factor(paste(annee, insee, sep = "_")),
    stfips_trend = as.factor(as.numeric(stfips_trend)),
  ) |>
  ungroup()



df_spill$tele<-df_spill$teletravail/df_spill$actifoccupe
df_spill$partcadre<-df_spill$cadre/df_spill$actifoccupe
df_spill$partinfocom<-df_spill$infocom_naf/df_spill$actifoccupe
df_spill$lteletravail<-log(df_spill$teletravail)
df_spill$lcadre<-log(df_spill$cadre)
df_spill$linfocom<-log(df_spill$infocom_naf)

df_spill$partnombreinfocom06<-df_spill$`Nombre.d.Ã©tablissements.2006.infocom`/df_spill$`Nombre.d.Ã©tablissements.2006`
df_spill$partnombreinfocom06<-ifelse(is.na(df_spill$partnombreinfocom06), 0, df_spill$partnombreinfocom06)


df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe




########## teleworkers

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers ", x = "Event Time", color = NULL)




###################### firm creation 



es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "nbrecreaentr",
  first_stage = ~ partcadre + partinfocom  | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of firm creations ", x = "Event Time", color = NULL)



################################################ Appendix C
df_spill <- df  |> group_by(annee) |>
  filter(annee <= 2022) |>
  # Create within indicator
  mutate(
    # Create D_it
    treat = as.numeric((datefibre <= annee) & (datefibre != 0)),
    # Create S_it
    within_25 = within_x_treat(15, annee, datefibre, geometry), ###ici ce sont les spillovers à 15km de la commune traitée tu peux le changer
    # S_it (1 - D_it)
    within_25 = within_25 * (1 - treat)
  ) |>
  ungroup() |>
  # Arrange panel by fips year
  arrange(insee, annee) |>
  group_by(insee) |>
  mutate(
    # Create D_it^k's
    rel_year = case_when(
      datefibre == 0 ~ -1,
      TRUE ~ annee - datefibre
    ),
    # Minimum year where S_it = 1
    year_within_25 = min_year(annee, within_25),
    # Create S_it^k
    spill_rel_year = case_when(
      year_within_25 == 0 ~ -Inf,
      treat == 1 ~ -Inf,
      TRUE ~ annee - year_within_25
    ),
    # max(D_it, S_it)
    treat_or_spill = treat + within_25,
    # Create trend variables for controls
    stfips_trend = as.factor(paste(annee, insee, sep = "_")),
    stfips_trend = as.factor(as.numeric(stfips_trend)),
  ) |>
  ungroup()



df_spill$tele<-df_spill$teletravail/df_spill$actifoccupe
df_spill$partcadre<-df_spill$cadre/df_spill$actifoccupe
df_spill$partinfocom<-df_spill$infocom_naf/df_spill$actifoccupe
df_spill$lteletravail<-log(df_spill$teletravail)
df_spill$lcadre<-log(df_spill$cadre)
df_spill$linfocom<-log(df_spill$infocom_naf)

df_spill$partnombreinfocom06<-df_spill$`Nombre.d.Ã©tablissements.2006.infocom`/df_spill$`Nombre.d.Ã©tablissements.2006`
df_spill$partnombreinfocom06<-ifelse(is.na(df_spill$partnombreinfocom06), 0, df_spill$partnombreinfocom06)



#################### impact on workers with chidren and on high intellectual prof (Appendix C)


########## workers with chidren 


df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



############## results without spillovers 

es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele_menenf",
    first_stage = ~ partcadre+  partinfocom + nbentrtot  | insee + annee,
    second_stage = ~ i(rel_year, ref = -1),
    treatment = "treat",
    cluster_var = "insee"
  )


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_1) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8)    
  + kfbmisc::theme_kyle(base_size = 12)  ) + labs(y = "Share of teleworkers", x = "Event Time", color = NULL)
es_plot_combined


############ result with spillovers

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele_menenf",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers ", x = "Event Time", color = NULL)





########################### Results on high intellectual professions


############# without spillovers 



es_1 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele_cadre",
    first_stage = ~ partcadre+  partinfocom + nbentrtot  | insee + annee,
    second_stage = ~ i(rel_year, ref = -1),
    treatment = "treat",
    cluster_var = "insee"
  )


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_1) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8)    
  + kfbmisc::theme_kyle(base_size = 12)  ) + labs(y = "Share of teleworkers", x = "Event Time", color = NULL)
es_plot_combined


############ result with spillovers

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele_cadre",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers ", x = "Event Time", color = NULL)







########################## resuts type of speed (Appendix D)


###### DATA on initial access to internet





t2015<-fread('taux_100mbits_t3_2015.csv', header=T, sep=';',dec='.', encoding = "Latin-1")
t2015$insee<-t2015$`Code INSEE`

df_spill <- df_spill  |>
  left_join(t2015, by = "insee") |>
  st_as_sf()

df_spill2<-df_spill
df_spill2$mbps30<-df_spill2$`30 Mbit/s et +15`


df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$t0_25 <- ifelse(df_spill2$mbps30 < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$mbps30 >= 0.25 & df_spill2$mbps30 < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$mbps30 >= 0.50 & df_spill2$mbps30 < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$mbps30 >= 0.75 & df_spill2$mbps30<= 1, 1, 0)



######### regressions for 30 mbps (table 3)
###### Categorie 1

df_spill2$rel_year = case_when(
  df_spill2$t0_25 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t0_25 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea0_25 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 +partcadre+  partinfocom | insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea0_25)

############ teleworkers 

es_1_tele0_25 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0+ partcadre+  partinfocom + nbentrtot| insee + annee,
    second_stage = ~  i(treat,0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele0_25)

###### Categorie 2

t2015<-fread('taux_100mbits_t3_2015.csv', header=T, sep=';',dec='.', encoding = "Latin-1")
t2015$insee<-t2015$`Code INSEE`

df_spill <- df_spill  |>
  left_join(t2015, by = "insee") |>
  st_as_sf()

df_spill2<-df_spill
df_spill2$mbps30<-df_spill2$`30 Mbit/s et +15`


df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$t0_25 <- ifelse(df_spill2$mbps30 < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$mbps30 >= 0.25 & df_spill2$mbps30 < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$mbps30 >= 0.50 & df_spill2$mbps30 < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$mbps30 >= 0.75 & df_spill2$mbps30<= 1, 1, 0)



df_spill2$rel_year = case_when(
  df_spill2$t25_50 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t25_50 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea25_50<- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 +partcadre+  partinfocom | insee + annee,
    second_stage = ~  i(treat,0)  ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea25_50)

############ teleworkers 

es_1_tele25_50 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0+ partcadre+  partinfocom + nbentrtot| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele25_50)



###### Categorie 3

t2015<-fread('taux_100mbits_t3_2015.csv', header=T, sep=';',dec='.', encoding = "Latin-1")
t2015$insee<-t2015$`Code INSEE`

df_spill <- df_spill  |>
  left_join(t2015, by = "insee") |>
  st_as_sf()

df_spill2<-df_spill
df_spill2$mbps30<-df_spill2$`30 Mbit/s et +15`


df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




df_spill2$t0_25 <- ifelse(df_spill2$mbps30 < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$mbps30 >= 0.25 & df_spill2$mbps30 < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$mbps30 >= 0.50 & df_spill2$mbps30 < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$mbps30 >= 0.75 & df_spill2$mbps30<= 1, 1, 0)



df_spill2$rel_year = case_when(
  df_spill2$t50_75 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t50_75 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea50_75<- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 +partcadre+  partinfocom | insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea50_75)

############ teleworkers 

es_1_tele50_75 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0+ partcadre+  partinfocom + nbentrtot| insee + annee,
    second_stage = ~  i(treat,0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele50_75)


###### Categorie 4

t2015<-fread('taux_100mbits_t3_2015.csv', header=T, sep=';',dec='.', encoding = "Latin-1")
t2015$insee<-t2015$`Code INSEE`

df_spill <- df_spill  |>
  left_join(t2015, by = "insee") |>
  st_as_sf()

df_spill2<-df_spill
df_spill2$mbps30<-df_spill2$`30 Mbit/s et +15`


df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)





df_spill2$t0_25 <- ifelse(df_spill2$mbps30 < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$mbps30 >= 0.25 & df_spill2$mbps30 < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$mbps30 >= 0.50 & df_spill2$mbps30 < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$mbps30 >= 0.75 & df_spill2$mbps30<= 1, 1, 0)



df_spill2$rel_year = case_when(
  df_spill2$t75_100 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t75_100 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea75_100<- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 +partcadre+  partinfocom | insee + annee,
    second_stage = ~  i(treat,0),
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea75_100)

############ teleworkers 

es_1_tele75_100 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0+ partcadre+  partinfocom + nbentrtot| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele75_100)




######### regressions for 100 mbps (table 4)


################ category 1

df_spill2<-df_spill

df_spill2$t0_25 <- ifelse(df_spill2$`100 Mbit/s et +15` < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.25 & df_spill2$`100 Mbit/s et +15` < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.50 & df_spill2$`100 Mbit/s et +15` < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$`100 Mbit/s et +15`>= 0.75 & df_spill2$`100 Mbit/s et +15`<= 1, 1, 0)




df_spill2$rel_year = case_when(
  df_spill2$t0_25 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t0_25 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea0_25 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 + partcadre+  partinfocom| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea0_25)




########  telework

es_1_tele0_25 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0 + partcadre+  partinfocom+nbentrtot| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele0_25)




################ category 2

df_spill2<-df_spill

df_spill2$t0_25 <- ifelse(df_spill2$`100 Mbit/s et +15` < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.25 & df_spill2$`100 Mbit/s et +15` < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.50 & df_spill2$`100 Mbit/s et +15` < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$`100 Mbit/s et +15`>= 0.75 & df_spill2$`100 Mbit/s et +15`<= 1, 1, 0)




df_spill2$rel_year = case_when(
  df_spill2$t25_50 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t25_50 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea25_50 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 + partcadre+  partinfocom| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea25_50)




########  telework

es_1_tele25_50 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0 + partcadre+  partinfocom|+nbentrtot insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele25_50)




################ category 3

df_spill2<-df_spill

df_spill2$t0_25 <- ifelse(df_spill2$`100 Mbit/s et +15` < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.25 & df_spill2$`100 Mbit/s et +15` < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.50 & df_spill2$`100 Mbit/s et +15` < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$`100 Mbit/s et +15`>= 0.75 & df_spill2$`100 Mbit/s et +15`<= 1, 1, 0)




df_spill2$rel_year = case_when(
  df_spill2$t50_75 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t50_75 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea50_75 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 + partcadre+  partinfocom|insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea50_75)




########  telework

es_1_tele50_75 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0 + partcadre+  partinfocom+nbentrtot| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele50_75)




################ category 4

df_spill2<-df_spill

df_spill2$t0_25 <- ifelse(df_spill2$`100 Mbit/s et +15` < 0.25, 1, 0)
df_spill2$t25_50 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.25 & df_spill2$`100 Mbit/s et +15` < 0.50, 1, 0)
df_spill2$t50_75 <- ifelse(df_spill2$`100 Mbit/s et +15` >= 0.50 & df_spill2$`100 Mbit/s et +15` < 0.75, 1, 0)
df_spill2$t75_100 <- ifelse(df_spill2$`100 Mbit/s et +15`>= 0.75 & df_spill2$`100 Mbit/s et +15`<= 1, 1, 0)




df_spill2$rel_year = case_when(
  df_spill2$t75_100 == 0  ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$t75_100 ==  0   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########### firm creation 
es_1_firmcrea75_100 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "nbrecreaentr",
    first_stage = ~ 0 + partcadre+  partinfocom | insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_firmcrea75_100)




########  telework

es_1_tele75_100 <- df_spill2 |>
  sf::st_drop_geometry() |>
  drop_na(stfips_trend) |>
  did2s::did2s(
    yname = "parttele",
    first_stage = ~ 0 + partcadre+  partinfocom+nbentrtot| insee + annee,
    second_stage = ~  i(treat,0) ,
    treatment = "treat_or_spill",
    cluster_var = "insee"
  )


summary(es_1_tele75_100)


################################################### Descriptive statics and parallel verification (Appendix E)



############### stats descriptives 

########### descriptive statitics 


# Charger les bibliothèques nécessaires
library(dplyr)
library(sf)
library(gtsummary)

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

# Si df_spill2 est un objet sf, retirer la géométrie
if ("sf" %in% class(df_spill2)) {
  df_spill2 <- st_drop_geometry(df_spill2)
}

# Sélectionner les variables en incluant 'treat' et en excluant la géométrie
monDF1 <- df_spill2 %>% 
  select(
    parttele, partcadre, partinfocom, partnombreinfocom06, 
    nbrecreaentr, nbentrinfocom, nbentrtot1000,
    teletravail, teletravail_menenf, teletravail_cadre, teletravail_infocom, 
    empouvrier, pop, nbremenage, actifoccupe, act_com)

# Vérifier et convertir 'treat' si nécessaire
if (is.list(monDF1$treat)) {
  monDF1$treat <- unlist(monDF1$treat)
}

# Créer le tableau de statistiques descriptives avec des labels personnalisés
monDF1 %>% 
  tbl_summary(
    label = list(
      parttele              ~ "Participation Télé",
      partcadre             ~ "Participation Cadres",
      partinfocom           ~ "Participation Infocom",
      partnombreinfocom06   ~ "Part Nombre Infocom 2006",
      nbrecreaentr          ~ "Nombre de Créations d'Entreprises",
      nbentrinfocom         ~ "Nombre d'Entreprises Infocom",
      nbentrtot1000         ~ "Nombre Total d'Entreprises (pour 1000 habitants)",
      teletravail           ~ "Télétravail",
      teletravail_menenf    ~ "Télétravail Ménages",
      teletravail_cadre     ~ "Télétravail Cadres",
      teletravail_infocom   ~ "Télétravail Infocom",
      empouvrier            ~ "Emploi Ouvrier",
      pop                   ~ "Population",
      nbremenage            ~ "Nombre de Ménages",
      actifoccupe           ~ "Actifs Occupés",
      act_com               ~ "Activité Commerciale"
    ),
    statistic = list(all_continuous() ~ "{mean}  {sd} {median} {min} {max}"),
    digits = all_continuous() ~ 1
  ) 





################ Evolution of the treatment 

library(dplyr)
library(sf)


df_spill2<-df_spill
df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)



########## number of treated units 
treated_counts <- df_spill2 %>%
  st_drop_geometry() %>%  # retire la colonne de géométrie
  group_by(annee) %>%
  summarise(treated_count = sum(treat == 1, na.rm = TRUE))

print(treated_counts)

############ number of control unit by year 

untreated_counts_ <- df_spill2 %>%
  st_drop_geometry() %>%  # retire la colonne de géométrie
  group_by(annee) %>%
  summarise(untreated_count = sum(treat == 0, na.rm = TRUE))

print(untreated_counts_)



################### Parallel trend verification 

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe




############ trend in term in total firm 

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "nbentrtot1000",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of firm  per 1,000 inhabitants ", x = "Event Time", color = NULL)


############ trend in term in total firm 

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele_cadre",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers in highly intellectual prof", x = "Event Time", color = NULL)

es_plot_combined

############# trend in infocom workers

############ trend in term in total firm 

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "parttele_menenf",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of workers with children", x = "Event Time", color = NULL)



######################################### Estimation with number of worker (Appendix F)


########## Data preparation 
df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


########################  Estimation without spillovers 




out = event_study(
  data = df_spill2, yname = "teletravail", idname = "insee",
  tname = "annee", gname = "datefibre", estimator = "all", xformla = ~ 0  )


plot_event_study(out, horizon = c(-10, 9))


#############################  estimation with spillovers 


es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "teletravail",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Share of teleworkers ", x = "Event Time", color = NULL)


################### IC city 



df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000







############### Sorting to keep IC sector 



df_spill2$spill_rel_year = case_when(
  df_spill2$partnombreinfocom06 <= 0.05        |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$spill_rel_year
)

df_spill2$year_within_25 = case_when(
  df_spill2$partnombreinfocom06 <= 0.05      |
    df_spill2$`Nombre.d.Ã©tablissements.2006.infocom` <= 21       ~ Inf,
  TRUE ~ df_spill2$year_within_25
)





df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)


es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "teletravail",
  first_stage = ~ partcadre + partinfocom  | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of teleworkers", x = "Event Time", color = NULL)


############################# types of cities 


################################## Number of teleworker 

df_spill2<-df_spill

df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000

df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)





df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe




########## densite =1


df_spill2$rel_year = case_when(
  df_spill2$densite == 4 | df_spill2$densite == 3  | df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite == 4  | df_spill2$densite ==3  | df_spill2$densite == 2 ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)




########################## graph

es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "teletravail",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of telewrkers", x = "Event Time", color = NULL)






######### densite = 2


df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 3| df_spill2$densite == 4   ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  3| df_spill2$densite == 1 | df_spill2$densite == 4  ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)
df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000





summary(es_1)


############ graph 


es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "teletravail",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of telewrkers", x = "Event Time", color = NULL)





################ densite = 3| densite = 4




df_spill2<-df_spill


df_spill2$parttele_cadre<-df_spill2$teletravail_cadre/df_spill2$actifoccupe
df_spill2$parttele_menenf<-df_spill2$teletravail_menenf/df_spill2$actifoccupe
df_spill2$parttele_infocom<-df_spill2$teletravail_infocom/df_spill2$actifoccupe



df_spill2$rel_year = case_when(
  df_spill2$densite == 1 | df_spill2$densite == 2     ~ -Inf,
  TRUE ~ df_spill2$rel_year
)

df_spill2$datefibre = case_when(
  df_spill2$densite ==  1| df_spill2$densite == 2   ~ -Inf,
  TRUE ~ df_spill2$datefibre
)


df_spill2$treat<-ifelse(df_spill2$rel_year>-1, 1,0)

df_spill2$spill<-ifelse(df_spill2$spill_rel_year==Inf |df_spill2$spill_rel_year<=-1 |df_spill2$spill_rel_year==-Inf , 0,1)
df_spill2$nbentrtot1000<-df_spill2$nbentrtot/1000





####################### graph
es_2 <- did2s::did2s(
  data = df_spill2 |>
    sf::st_drop_geometry() |>
    # Filter out NAs
    drop_na( stfips_trend),
  yname = "teletravail",
  first_stage = ~ partcadre + partinfocom + nbentrtot   | insee + annee,
  second_stage = ~ i(rel_year, -1) + i(spill_rel_year, ref = -Inf),
  treatment = "treat_or_spill",
  cluster_var = "insee"
)


##1.645 pour 90% confidence intervalle et 2.576 pour 99% 1.96 pour 95%
es_pts_combined <- broom::tidy(es_2) |>
  mutate(
    # Split term to variable and relative time
    term_split = str_split(term, "::"),
    term = unlist(lapply(term_split, \(x) x[1])),
    time = unlist(lapply(term_split, \(x) x[2])),
    time = as.numeric(time),
    # Confidence interval
    ub = estimate + 1.645 * std.error,
    lb = estimate - 1.645 * std.error,
    # Term for plotting
    group = case_when(
      term == "rel_year" ~ "Treatment Effect",
      term == "spill_rel_year" ~ "Spillover On Control",
    )
  ) |>
  # Filter years to match original
  filter(time <= 10 & time >= -9) |>
  # Shift for plotting
  mutate(time = if_else(term == "rel_year", time + 0.2, time - 0.2))

# Add -1 for plotting
es_pts_combined <- bind_rows(
  es_pts_combined,
  tibble(time = c(-1.2, -0.8), estimate = c(0, 0), ub = c(0, 0), lb = c(0, 0), group = c("Spillover On Control", "Treatment Effect"))
)

(es_plot_combined <- ggplot(es_pts_combined) +
    geom_vline(xintercept = -0.5, color = "grey50") +
    geom_hline(yintercept = 0, color = "black") +
    geom_point(aes(x = time, y = estimate, color = group)) +
    geom_errorbar(aes(x = time, ymin = lb, ymax = ub, color = group), alpha = 0.8) +
    kfbmisc::theme_kyle(base_size = 12)
) + labs(y = "Number of telewrkers", x = "Event Time", color = NULL)






